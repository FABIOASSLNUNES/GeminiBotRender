==============================
GeminiBotRender - Plug & Play
==============================

🚀 Como rodar no Render (plano Free)
------------------------------------
1) Crie um repositório no GitHub e suba os arquivos deste projeto.

   Exemplo de comandos (na pasta do projeto):
     git init
     git add .
     git commit -m "Gemini WhatsApp Bot"
     git branch -M main
     git remote add origin https://github.com/SEU_USUARIO/GeminiBotRender.git
     git push -u origin main

2) No Render (https://render.com):
   - New +  -> Web Service
   - Conecte ao seu GitHub e selecione este repositório
   - Build Command: npm install
   - Start Command: npm start
   - Plan: Free

3) Após o deploy, abra os Logs do serviço.
   Se não houver GEMINI_API_KEY definida, o app exibirá instruções para
   acessar a rota /setup e inserir a chave via formulário.

   - Abra a URL do seu serviço (ex: https://SEU-APP.onrender.com/setup)
   - Cole sua GEMINI_API_KEY
   - O bot será iniciado e o QR aparecerá nos logs.

4) Conecte seu WhatsApp:
   WhatsApp > Dispositivos Conectados > Conectar > Escanear QR

5) Teste enviando mensagens para o número conectado:
   "oi"
   "quem é você?"
   "crie uma frase criativa pra hamburguer artesanal"

⚙️ Dicas
--------
- Para trocar a chave no Render, reinicie o serviço e acesse /setup de novo.
- Você também pode definir GEMINI_API_KEY como variável de ambiente no painel do Render.
- A rota /ping retorna "ok" para monitoramento.

▶️ Rodar localmente (opcional)
------------------------------
- Instale Node.js 18+
- Na pasta do projeto:
    npm install
    npm start
- Se estiver em TTY, o app pedirá a GEMINI_API_KEY no terminal.
- Caso contrário, acesse http://localhost:3000/setup e envie a chave pelo formulário.
